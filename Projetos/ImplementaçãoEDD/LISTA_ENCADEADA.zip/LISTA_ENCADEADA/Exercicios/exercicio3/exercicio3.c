#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef int ITEM;

typedef struct estrutura {
    ITEM item;
    struct estrutura *prox;
} NO;

typedef struct {
    NO *cabeca;
    int tamanho;
} LISTA;

void inicializar(LISTA *l) {
    l->cabeca = NULL;
    l->tamanho = 0;
}

NO *criarNo(ITEM item, NO *prox) {
    NO *pNovo = (NO *)malloc(sizeof(NO));
    if (pNovo == NULL) {
        printf("Nao foi possivel alocar memoria para pNovo\n");
        exit(EXIT_FAILURE);
    }
    pNovo->item = item;
    pNovo->prox = prox;
    return pNovo;
}

bool inserir(ITEM item, LISTA *l) {
    l->cabeca = criarNo(item, l->cabeca);
    l->tamanho++;
    return true;
}

void imprimirItem(ITEM i) {
    printf("%d", i);
}

void imprimirLista(LISTA *l) {
    printf("[");
    NO *p = l->cabeca;
    while (p) {
        imprimirItem(p->item);
        if (p->prox) {
            printf(",");
        }
        p = p->prox;
    }
    printf("]\n");
}

void testarInserir(LISTA *l) {
    printf("=> Teste de Inserir\n");
    int qtd;
    printf("Quantos itens deseja guardar na lista? ");
    scanf("%d", &qtd);

    ITEM item;
    int i;
    for (i = 1; i <= qtd; i++) {
        printf("Digite o valor %d/%d: ", i, qtd);
        scanf("%d", &item);
        inserir(item, l);
    }
}

void destruir(LISTA *l) {
    NO *atual = l->cabeca;
    while (atual) {
        NO *prox = atual->prox;
        free(atual);
        atual = prox;
    }
    l->cabeca = NULL;
    l->tamanho = 0;
}

LISTA *clonar(LISTA *l) {
    LISTA *novaLista = (LISTA *)malloc(sizeof(LISTA));
    if (novaLista == NULL) {
        printf("Erro ao alocar memoria para a nova lista\n");
        exit(EXIT_FAILURE);
    }

    inicializar(novaLista); // Inicializa a nova lista

    NO *p = l->cabeca;
    while (p != NULL) {
        inserir(p->item, novaLista); // Insere copia do item na nova lista
        p = p->prox;
    }

    // Reverte a nova lista para que os itens fiquem na ordem correta
    LISTA *listaRevertida = (LISTA *)malloc(sizeof(LISTA));
    if (listaRevertida == NULL) {
        printf("Erro ao alocar memoria para a lista revertida\n");
        exit(EXIT_FAILURE);
    }

    inicializar(listaRevertida);

    NO *q = novaLista->cabeca;
    while (q != NULL) {
        listaRevertida->cabeca = criarNo(q->item, listaRevertida->cabeca);
        listaRevertida->tamanho++;
        q = q->prox;
    }

    destruir(novaLista);
    free(novaLista);

    return listaRevertida;
}


int main() {
    LISTA l;

    inicializar(&l);
    testarInserir(&l);
    imprimirLista(&l);

    LISTA *novaLista = clonar(&l);
    printf("Lista clonada: ");
    imprimirLista(novaLista);

    destruir(&l);
    destruir(novaLista);
    free(novaLista);

    return 0;
}
